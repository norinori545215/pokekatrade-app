【起動方法】
1. 環境変数 'SECRET_KEY' を設定（例: export SECRET_KEY=mysecret）
2. `python app.py` でローカル実行
3. Render/Herokuにデプロイも可能（requirements.txt, Procfile付き）
4. http://localhost:5000/admin で管理画面にアクセス可能
5. 招待コード: TRIAL-2025-1234
